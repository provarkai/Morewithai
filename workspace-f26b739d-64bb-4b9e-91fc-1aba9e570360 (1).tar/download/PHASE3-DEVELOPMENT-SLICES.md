# Phase 3 — Technical Build Map: Development Slices

## Sprint Plan (8 Sprints, 34 Slices)

### Sprint 1: Multi-Site + SaaS Foundation + Portfolio Dashboard (P0)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.1 | Site model expansion — niche, brand voice, autonomy level, monetization/SEO/analytics JSON settings | §3 |
| 3.2 | Organization, OrganizationMember, Plan, Subscription, UsageRecord models | §48-54 |
| 3.3 | Site Health Score service (content, SEO, traffic, monetization, freshness) | §5 |
| 3.4 | Portfolio Dashboard — cross-site metrics, top performers, risks, opportunities | §6 |
| 3.5 | Site Portfolio UI — site cards, site switcher, site create/settings with new fields | §4 |

### Sprint 2: Content Orchestrator + Priority/ROI Engine (P0)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.6 | ContentJob model + queue service (research→outline→generate→seo→quality→publish→promote→refresh) | §8-9 |
| 3.7 | Priority Engine — scoring based on traffic potential, revenue, competition, ROI | §10 |
| 3.8 | ROI Engine — expected traffic, conversion, revenue, cost, ROI calculation | §11 |
| 3.9 | Content Orchestrator service — coordinates full pipeline, manages state transitions | §7 |
| 3.10 | Content Queue UI — job list, status tracking, retry, priority management | §9 |

### Sprint 3: AI Infrastructure (P0/P1)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.11 | AI Model Router — task classification, model selection, cost/quality tradeoff | §26-27 |
| 3.12 | AI Failure Recovery — fallback providers, retry with backoff, never silent failure | §28 |
| 3.13 | Agent Audit Log — every agent action recorded with full context | §33-34 |
| 3.14 | Content Quality Memory + Prompt Versioning — learn from outcomes, version prompts | §35-36 |
| 3.15 | AI Learning Loop — measure→learn→update strategy cycle | §38 |

### Sprint 4: Revenue Intelligence (P1/P2)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.16 | CostEvent, ProfitMetric models + Profit Engine service | §23-24 |
| 3.17 | Revenue Optimizer — AI recommends best monetization per article | §20-21 |
| 3.18 | Revenue Experimentation engine (RevenueExperiment, RevenueVariant) | §22 |
| 3.19 | Revenue Forecasting (ranges, not false precision) | §19 |
| 3.20 | Business Goals + Goal Engine + AI Business Strategist | §82-84 |

### Sprint 5: Content Intelligence (P0/P1/P2)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.21 | Content Gap Engine — missing topics, weak subtopics, uncovered intent | §15 |
| 3.22 | Topical Authority Graph expansion (Topic, TopicRelationship, ArticleTopic) | §14 |
| 3.23 | Content Portfolio Classification (STAR/HIGH POTENTIAL/STABLE/DECLINING/LOW VALUE) | §12 |
| 3.24 | Content Decay Engine + Automated Refresh Priority + Consolidation Engine | §74-76 |
| 3.25 | Repurposing Engine + Content Distribution Score | §77-79 |

### Sprint 6: Operations & Safety (P0/P1)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.26 | Scheduled Tasks + Cron/Worker architecture | §39-41 |
| 3.27 | SystemHealth, WorkerHealth, ProviderHealth + Observability | §42 |
| 3.28 | Alerting system + Admin Operations Centre | §43-44 |
| 3.29 | Human Approval Queue + Automation Safety + Autonomy Levels | §29-31 |
| 3.30 | Experiment Engine (generic — content, SEO, CTA, affiliate, email, product) | §37 |

### Sprint 7: Integrations & API (P1/P2)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.31 | Webhook system (Webhook, WebhookEvent) + delivery service | §60 |
| 3.32 | Public API with API keys (hashed, scoped, revocable) | §61-62 |
| 3.33 | Integration provider abstractions (Analytics, WordPress, Email, Payments, AI) | §59 |
| 3.34 | Billing architecture (provider-agnostic subscription management) | §55 |

### Sprint 8: Security, Backup & Polish (P0/P2)
| Slice | Description | Spec Sections |
|---|---|---|
| 3.35 | AuditLog model + audit middleware + Audit Log UI | §67 |
| 3.36 | Backup & Disaster Recovery (automated DB backup, export, recovery) | §63-64 |
| 3.37 | Feature Flags (FeatureFlag model + service) | §69 |
| 3.38 | Security Hardening (CSP, secure headers, 2FA foundation, secret management) | §66, §70 |
| 3.39 | Command Centre homepage + Next Best Action engine | §85-87 |
| 3.40 | Revenue Diversification Alert + Concentration detection | §80-81 |
| 3.41 | Executive AI Report + Business Intelligence Dashboard | §45-47 |
| 3.42 | Competitor Intelligence + Competitive Content Gap | §16-17 |
| 3.43 | Predictive Traffic Engine | §18 |
| 3.44 | Full QA + Performance check + sidebar restructure per §86 | §71 |

---

## P0 Priority (Must Ship First)
- Multi-Site Management (3.1)
- SaaS Foundation (3.2)
- Portfolio Dashboard (3.4)
- Content Queue (3.6, 3.10)
- Content Orchestrator (3.9)
- ROI Engine (3.8)
- Priority Engine (3.7)
- AI Failure Recovery (3.12)
- Content Gap Engine (3.21)
- Backup & DR (3.36)
