# PHASE 1 — AI PUBLISHING ENGINE
## Development Slice Plan

**Project**: MoreWithAI Blogging Platform V2
**Stack**: Next.js 16 / React 19 / TypeScript / Prisma 6 / SQLite / Tailwind / shadcn
**Objective**: Upgrade from RSS rewriter to professional AI publishing engine

---

## SLICE OVERVIEW

| Slice | Phase | Title | Dependencies | Est. Effort |
|-------|-------|-------|-------------|-------------|
| S1 | 1A | Authentication & RBAC | None | Medium |
| S2 | 1B | Database Schema Expansion | S1 | Medium |
| S3 | 1B | Article Status & Lifecycle System | S2 | Small |
| S4 | 1C | Article Editor Workspace — Layout & Toolbar | S2 | Medium |
| S5 | 1C | Article Editor — Content Editing & Autosave | S4 | Medium |
| S6 | 1C | Article Editor — Metadata & Publishing Panel | S4, S3 | Medium |
| S7 | 1D | AI Client & Prompt Architecture | S2 | Medium |
| S8 | 1D | AI Research & Source Analysis | S7 | Medium |
| S9 | 1D | AI Outline Generator | S7 | Medium |
| S10 | 1D | AI Article Generator (Multi-Mode) | S7, S9 | Large |
| S11 | 1E | SEO Analyzer & Scoring Engine | S10 | Large |
| S12 | 1E | Quality Scoring Engine | S11 | Medium |
| S13 | 1E | SEO Panel (Editor Integration) | S11, S4 | Medium |
| S14 | 1F | Internal Linking Engine | S2 | Medium |
| S15 | 1F | Category & Tag System with AI | S2, S7 | Medium |
| S16 | 1G | Author System | S2 | Medium |
| S17 | 1G | Article Versioning | S2, S4 | Medium |
| S18 | 1H | Content Refresh Engine | S7, S17, S12 | Medium |
| S19 | 1I | AI Job Queue & Cost Tracking | S7 | Medium |
| S20 | 1I | API Route Restructure | S1–S19 | Large |
| S21 | 1I | Dashboard Upgrade | S3, S12, S14, S18 | Medium |
| S22 | 1I | Public Blog Enhancements | S2, S16 | Medium |
| S23 | 1J | Bug Fixes & Existing Code Cleanup | None | Small |
| S24 | 1J | Final Integration & Security Audit | All | Medium |

---

## DETAILED SLICE BREAKDOWN

---

### SLICE S1 — AUTHENTICATION & RBAC
**Phase**: 1A — Security + Authentication
**Dependencies**: None
**Status**: ⬜ Not Started

#### What exists today
- `AUTH_PASSWORD` env var compared in `src/middleware.ts`
- `Authorization: Bearer <password>` header check
- `auth_key` query parameter bypass (INSECURE)
- `src/components/login-gate.tsx` — simple card UI password entry
- `sessionStorage` stores password in browser (INSECURE)
- `next-auth` in `package.json` but completely unused

#### What this slice delivers
1. **User model** with email, name, passwordHash, role, isActive
2. **Session model** with HTTP-only secure cookies
3. **Login API** (`POST /api/auth/login`) — email/password, sets http-only session cookie
4. **Logout API** (`POST /api/auth/logout`) — clears session
5. **Session validation API** (`GET /api/auth/session`) — returns current user
6. **Password reset API** (`POST /api/auth/reset`) — architecture ready (email sending deferred)
7. **Middleware rewrite** — replaces Bearer token with cookie-based session validation
8. **RBAC system** — ADMIN, EDITOR, AUTHOR roles with capability-based permissions
9. **Auth library** — `src/lib/auth/config.ts`, `session.ts`, `password.ts`, `permissions.ts`, `guards.ts`
10. **Login UI upgrade** — email/password form replacing single password field
11. **Rate limiting** on auth endpoints (5 attempts/minute)
12. **Remove** all insecure patterns: `auth_key` query param, sessionStorage password, plain password comparison

#### Files to create
```
src/lib/auth/
  config.ts          — Auth config (session expiry, cookie name, etc.)
  password.ts        — bcrypt hash/verify
  session.ts         — Create/validate/destroy sessions
  permissions.ts     — Role→permission mapping
  guards.ts          — requireAuth(), requireRole(), requirePermission()

src/app/api/auth/
  login/route.ts     — POST: email/password → session cookie
  logout/route.ts    — POST: clear session
  session/route.ts   — GET: current user info
  password/route.ts  — POST: reset request (architect)
```

#### Files to modify
- `src/middleware.ts` — Complete rewrite for cookie-based session auth
- `src/components/login-gate.tsx` — Email/password form UI
- `prisma/schema.prisma` — Add User, Session models
- `src/lib/api.ts` — Remove Bearer token auth, use credentials: 'include'

#### Files to delete
- Remove `AUTH_PASSWORD` env var usage
- Remove `auth_key` query param support

#### Acceptance criteria
- [ ] User can log in with email/password
- [ ] Session stored as HTTP-only cookie
- [ ] Protected routes return 401 without valid session
- [ ] ADMIN sees all features
- [ ] EDITOR cannot access user management or site deletion
- [ ] AUTHOR can only create/edit own drafts
- [ ] Rate limiting blocks >5 login attempts/minute
- [ ] No passwords in URLs, sessionStorage, or frontend JS

---

### SLICE S2 — DATABASE SCHEMA EXPANSION
**Phase**: 1B — Database + Content Model
**Dependencies**: S1 (User model)
**Status**: ⬜ Not Started

#### What exists today
- 5 models: Site, RssFeed, Article, Setting, AutomationLog
- Article does too much (content + SEO + publishing + source + scheduling)
- No Author, Category, Tag, Version, Score, or Job models

#### What this slice delivers
1. **Author model** — separate from User (public identity vs system identity)
2. **Category model** — hierarchical (parentId), with SEO fields
3. **Tag model** — with slug and description
4. **ArticleTag** — many-to-many join table
5. **ArticleVersion** — version history with versionNumber
6. **ArticleSource** — multi-source tracking (RSS, URL, MANUAL, RESEARCH)
7. **SeoAnalysis** — detailed SEO scoring breakdown
8. **ContentScore** — quality scoring breakdown
9. **InternalLinkRecommendation** — suggested links with relevance
10. **ContentRefresh** — refresh tracking with reasons
11. **AiJob** — AI operation tracking with token/cost tracking
12. **Article field extensions** — slug, excerpt, authorId, categoryId, primaryKeyword, searchIntent, readingTime, wordCount, seoScore, qualityScore, lastReviewedAt, nextReviewAt, publishedVersionId
13. **Database indexes** — on siteId, status, publishedAt, category, etc.

#### Files to create
- `prisma/migrations/` — Migration files (auto-generated)

#### Files to modify
- `prisma/schema.prisma` — Add 11 new models + extend Article

#### Migration strategy
- Keep ALL existing Article fields for backward compatibility
- Add new fields as nullable where existing data doesn't have values
- Create default Author record per existing Site during migration
- Map existing `category` string field → first Category record

#### Acceptance criteria
- [ ] `prisma migrate dev` runs without error
- [ ] Existing Site, RssFeed, Article, Setting, AutomationLog data preserved
- [ ] New tables created: User, Session, Author, Category, Tag, ArticleTag, ArticleVersion, ArticleSource, SeoAnalysis, ContentScore, InternalLinkRecommendation, ContentRefresh, AiJob
- [ ] Article has all new fields
- [ ] Indexes created on key query columns

---

### SLICE S3 — ARTICLE STATUS & LIFECYCLE SYSTEM
**Phase**: 1B — Database + Content Model
**Dependencies**: S2
**Status**: ⬜ Not Started

#### What exists today
- Free-form status strings: `fetched`, `rewriting`, `rewritten`, `approved`, `rejected`, `scheduled`, `publishing`, `published`, `failed`
- No validation on status transitions
- No centralized status logic

#### What this slice delivers
1. **Status constants** — `src/lib/articles/status.ts` with all valid statuses
2. **Workflow transitions** — `src/lib/articles/workflow.ts` — valid state machine
3. **Validation** — `src/lib/articles/validation.ts` — publishing gates
4. **Status enum** — IDEA, FETCHED, RESEARCHING, OUTLINE, DRAFT, AI_REVIEW, EDITOR_REVIEW, APPROVED, SCHEDULED, PUBLISHED, UPDATING, UPDATED, ARCHIVED, FAILED
5. **Transition validation** — e.g., DRAFT→PUBLISHED blocked without explicit override
6. **Publishing gates** — check content, title, slug, category, author, SEO fields, quality score
7. **Score override** — record who/when/reason when bypassing thresholds

#### Files to create
```
src/lib/articles/
  status.ts         — Status enum/constants
  workflow.ts       — Valid transitions, canTransition()
  validation.ts     — Publishing gate checks
```

#### Files to modify
- `src/app/api/articles/route.ts` — Use workflow for status changes
- `src/components/app/status-badge.tsx` — Add new statuses
- All status-touching routes — Use workflow.canTransition()

#### Status lifecycle
```
IDEA → FETCHED → RESEARCHING → OUTLINE → DRAFT → AI_REVIEW → EDITOR_REVIEW
  → APPROVED → SCHEDULED → PUBLISHED → UPDATING → UPDATED → ARCHIVED
                                                         ↘ FAILED (from any)
```

#### Acceptance criteria
- [ ] All status constants defined in one place
- [ ] Invalid transitions return clear error
- [ ] Publishing blocked if gates not met (with specific messages)
- [ ] Admin can override with reason recorded
- [ ] StatusBadge component supports all new statuses

---

### SLICE S4 — ARTICLE EDITOR WORKSPACE — LAYOUT & TOOLBAR
**Phase**: 1C — Editorial Workspace
**Dependencies**: S2
**Status**: ⬜ Not Started

#### What exists today
- `src/components/views/articles-view.tsx` (431 lines) — monolithic table + detail Sheet
- Basic article editing in a Sheet side panel
- `src/components/seo-panel.tsx` — standalone SEO metadata editor

#### What this slice delivers
1. **Editor layout** — Full-page editor with left content area + right panel tabs
2. **Editor toolbar** — Save draft, submit review, schedule, publish buttons
3. **Status bar** — Shows current status, category, author, quality/SEO scores
4. **Right panel tabs** — AI, SEO, Quality, Links, Publishing
5. **Navigation** — Back to articles list, prev/next article
6. **Mobile responsive** — Right panel collapses to bottom drawer/tabs

#### Files to create
```
src/components/editor/
  article-editor.tsx       — Main editor layout (split pane)
  article-toolbar.tsx      — Top action bar
  article-status.tsx       — Status display + transitions
  article-ai-panel.tsx      — AI command center tab
  article-publish-panel.tsx — Publishing controls tab
```

#### Files to modify
- `src/app/page.tsx` — Add `/editor/[id]` route view
- `src/components/app/app-sidebar.tsx` — Add editor navigation state

#### Acceptance criteria
- [ ] Editor loads for a given article ID
- [ ] Left panel shows article title + content area
- [ ] Right panel has 5 tabs (AI, SEO, Quality, Links, Publishing)
- [ ] Toolbar shows save/submit/schedule/publish actions
- [ ] Status bar shows status, category, author, scores
- [ ] Mobile: right panel accessible via bottom tabs/drawer

---

### SLICE S5 — ARTICLE EDITOR — CONTENT EDITING & AUTOSAVE
**Phase**: 1C — Editorial Workspace
**Dependencies**: S4
**Status**: ⬜ Not Started

#### What exists today
- Article content edited as plain textarea in a Sheet
- No autosave
- No word count / reading time display
- No article statistics

#### What this slice delivers
1. **Rich text editor** — Using `@mdxeditor/editor` (already in deps, unused) or TipTap
2. **Title editing** — Inline editable H1
3. **Slug editing** — Auto-generated from title, editable, locked after publish
4. **Excerpt editing** — Textarea with character count
5. **Autosave** — 1-3 second debounce after typing stops
6. **Save status indicator** — "Saved" / "Saving..." / "Unsaved changes" / "Save failed"
7. **Article statistics** — Word count, reading time, paragraph count, heading count, image count, internal/external link count
8. **Featured image** — URL input with preview

#### Files to create
```
src/components/editor/
  article-content-editor.tsx  — Rich text/HTML editor component
  article-metadata.tsx        — Slug, excerpt, featured image, stats display
```

#### Files to modify
- `src/components/editor/article-editor.tsx` — Integrate content editor

#### Acceptance criteria
- [ ] Can edit article title and content with rich formatting
- [ ] Slug auto-generates from title
- [ ] Autosave triggers 2 seconds after last keystroke
- [ ] Save status indicator shows current state
- [ ] Statistics display: words, reading time, headings, images, links
- [ ] Featured image URL shows preview
- [ ] Content not lost when AI operations fail

---

### SLICE S6 — ARTICLE EDITOR — METADATA & PUBLISHING PANEL
**Phase**: 1C — Editorial Workspace
**Dependencies**: S4, S3
**Status**: ⬜ Not Started

#### What exists today
- `src/components/seo-panel.tsx` — SEO title, description, keywords, schema, AdSense toggle
- Basic scheduling dialog in articles-view

#### What this slice delivers
1. **Enhanced SEO panel** — Migrate from seo-panel.tsx, add to editor right tabs
2. **Author selector** — Dropdown to assign author
3. **Category selector** — Hierarchical category picker
4. **Tag input** — Multi-select with create-new
5. **Schedule controls** — Date/time picker for scheduling
6. **Publishing panel** — Pre-publish checks, publish/unschedule buttons
7. **Quality panel placeholder** — Scores display (populated by S12)
8. **Links panel placeholder** — Internal link recommendations (populated by S14)

#### Files to create
```
src/components/editor/
  article-seo-panel.tsx       — SEO metadata editor (migrated from seo-panel.tsx)
  article-quality-panel.tsx   — Quality score display (placeholder until S12)
  article-links-panel.tsx     — Internal link recommendations (placeholder until S14)
  article-history-panel.tsx   — Version history (placeholder until S17)
```

#### Files to modify
- `src/components/editor/article-editor.tsx` — Wire panels into right sidebar tabs
- `src/components/seo-panel.tsx` — Deprecate (migrate to editor panel)

#### Acceptance criteria
- [ ] SEO panel shows: title, description, keywords, canonical URL, schema preview
- [ ] Author selector lists site authors
- [ ] Category selector shows hierarchy
- [ ] Tag input supports multi-select and inline creation
- [ ] Schedule date/time picker works
- [ ] Publishing panel shows pre-publish checklist
- [ ] Panels work as tabs in the right sidebar

---

### SLICE S7 — AI CLIENT & PROMPT ARCHITECTURE
**Phase**: 1D — AI Editorial Engine
**Dependencies**: S2
**Status**: ⬜ Not Started

#### What exists today
- `src/lib/services/rewrite.service.ts` — Single LLM call with hardcoded prompt
- Prompt embedded in service function (129 lines)
- No Zod validation of AI responses
- No token/usage tracking
- No retry logic
- Direct `z-ai-web-dev-sdk` usage scattered in route

#### What this slice delivers
1. **AI client abstraction** — `src/lib/ai/client.ts` — Provider config, request execution, retry, timeout, error normalization, usage tracking
2. **Prompt management** — `src/lib/ai/prompts.ts` — Centralized prompt functions for each operation
3. **Zod schemas** — `src/lib/ai/schemas.ts` — Validate every AI response shape
4. **AI service refactor** — Keep existing `rewrite.service.ts` working but route through new client
5. **Usage tracking** — Log model, input/output tokens, estimated cost per operation
6. **Error normalization** — Standard error types: timeout, rate limit, invalid response, provider error

#### Files to create
```
src/lib/ai/
  client.ts      — AI provider abstraction (init, call, retry, track usage)
  prompts.ts     — getResearchPrompt(), getOutlinePrompt(), getArticlePrompt(), etc.
  schemas.ts     — Zod schemas for each AI response type
  types.ts       — Shared AI types (generation modes, tones, audiences, etc.)
  errors.ts      — AI-specific error classes
```

#### Files to modify
- `src/lib/services/rewrite.service.ts` — Refactor to use ai/client.ts
- `src/app/api/rewrite/route.ts` — Use new service interface

#### Acceptance criteria
- [ ] All AI calls go through centralized client
- [ ] Every AI response validated against Zod schema
- [ ] Token usage logged to AiJob table
- [ ] Retry on timeout (1 retry, exponential backoff)
- [ ] Prompts are in one file, not scattered in routes
- [ ] Existing rewrite functionality still works

---

### SLICE S8 — AI RESEARCH & SOURCE ANALYSIS
**Phase**: 1D — AI Editorial Engine
**Dependencies**: S7
**Status**: ⬜ Not Started

#### What exists today
- No research step — articles go directly from fetched to rewritten
- No source analysis, fact extraction, or content gap identification

#### What this slice delivers
1. **Research service** — `src/lib/ai/editorial.service.ts` — `researchArticle()`
2. **Source analysis** — Extract: main topic, key claims, facts, entities, dates, statistics, quotes, arguments
3. **Content gap analysis** — Identify what's missing, what angles are unexplored
4. **Original angle generation** — Suggest unique angle, target reader, search intent, UVP
5. **Research API** — `POST /api/ai/research`
6. **Research UI** — Show research results in editor AI panel

#### Files to create
```
src/lib/ai/
  editorial.service.ts  — researchArticle(), analyzeSource(), generateAngle()

src/app/api/ai/
  research/route.ts  — POST: trigger research for an article
```

#### Files to modify
- `src/components/editor/article-ai-panel.tsx` — Add research button + results display

#### Acceptance criteria
- [ ] Research extracts key facts, entities, claims from source
- [ ] Content gaps identified
- [ ] Original angle suggested with reasoning
- [ ] Results stored and displayed in editor
- [ ] API creates AiJob record with usage tracking

---

### SLICE S9 — AI OUTLINE GENERATOR
**Phase**: 1D — AI Editorial Engine
**Dependencies**: S7
**Status**: ⬜ Not Started

#### What exists today
- No outline step — AI generates full article directly

#### What this slice delivers
1. **Outline service** — `src/lib/ai/editorial.service.ts` — `generateOutline()`
2. **Outline structure** — H1, Introduction, H2/H3 sections, FAQ, Conclusion, CTA
3. **Editable outline** — User can modify AI-generated outline before article generation
4. **Outline API** — `POST /api/ai/outline`
5. **Outline UI** — Editable outline component in editor AI panel
6. **Regenerate** — Can regenerate outline without losing research

#### Files to create
```
src/components/editor/
  article-outline-panel.tsx  — Editable outline with accept/edit/regenerate

src/app/api/ai/
  outline/route.ts  — POST: generate outline from research/article
```

#### Files to modify
- `src/lib/ai/editorial.service.ts` — Add generateOutline()
- `src/lib/ai/prompts.ts` — Add getOutlinePrompt()
- `src/lib/ai/schemas.ts` — Add outline response schema
- `src/components/editor/article-ai-panel.tsx` — Add outline section

#### Acceptance criteria
- [ ] AI generates structured H1/H2/H3 outline with FAQ
- [ ] Outline is editable in the UI
- [ ] "Regenerate" creates new outline
- [ ] "Accept" locks outline for article generation
- [ ] Outline stored with article for reference

---

### SLICE S10 — AI ARTICLE GENERATOR (MULTI-MODE)
**Phase**: 1D — AI Editorial Engine
**Dependencies**: S7, S9
**Status**: ⬜ Not Started

#### What exists today
- Single rewrite mode: take source → rewrite with SEO
- One prompt, one tone, one approach
- No concept of original angle or generation modes

#### What this slice delivers
1. **Multi-mode generation** — NEWS, EXPLAINER, GUIDE, LISTICLE, COMPARISON, REVIEW, OPINION, EVERGREEN
2. **Article service** — `src/lib/ai/editorial.service.ts` — `generateArticle()`
3. **Configurable settings** — Tone (professional, conversational, educational, journalistic, expert, friendly), Length (short, standard, long, deep-dive), Audience (beginner, intermediate, expert, business, consumer)
4. **Originality enforcement** — Prompt instructions to add value, not copy
5. **Generation from outline** — Uses accepted outline as structure
6. **Generation API** — `POST /api/ai/generate`
7. **Generation UI** — Mode selector, tone/length/audience dropdowns, generate button, progress
8. **Improve article** — `POST /api/ai/improve` — enhance existing content

#### Files to create
```
src/app/api/ai/
  generate/route.ts  — POST: generate article from outline/research
  improve/route.ts   — POST: improve existing article content
```

#### Files to modify
- `src/lib/ai/editorial.service.ts` — Add generateArticle(), improveArticle()
- `src/lib/ai/prompts.ts` — Add getArticlePrompt(), getImprovePrompt() for each mode
- `src/lib/ai/schemas.ts` — Add article generation response schema
- `src/components/editor/article-ai-panel.tsx` — Add generation controls

#### Acceptance criteria
- [ ] 8 generation modes available (NEWS, EXPLAINER, GUIDE, etc.)
- [ ] Tone, length, audience configurable before generation
- [ ] Article generated from accepted outline
- [ ] Content is original (not sentence-level rewrite)
- [ ] AI adds context, implications, examples, practical info
- [ ] Generation creates AiJob record
- [ ] "Improve" enhances existing article
- [ ] Draft not lost if AI fails

---

### SLICE S11 — SEO ANALYZER & SCORING ENGINE
**Phase**: 1E — SEO + Quality Engine
**Dependencies**: S10
**Status**: ⬜ Not Started

#### What exists today
- SEO fields stored on Article (seoTitle, seoDescription, seoKeywords, seoSchema)
- SEO panel UI for editing metadata
- No automated SEO analysis or scoring

#### What this slice delivers
1. **SEO analyzer** — `src/lib/seo/analyzer.ts` — Analyze article content for SEO
2. **SEO scoring** — `src/lib/seo/scoring.ts` — Score 0-100 with breakdown
3. **SEO checklist** — Auto-check 15+ items (keyword in title, meta desc length, heading structure, image alt text, internal/external links, FAQ, schema, canonical, OG)
4. **Score breakdown** — Title (10), Meta (10), Keyword (10), Structure (10), Search Intent (15), Internal Links (15), External Authority (10), Readability (10), Schema (5), URL (5)
5. **Recommendations** — Specific improvement suggestions with "Fix with AI" buttons
6. **Search intent** — INFORMATIONAL, COMMERCIAL, TRANSACTIONAL, NAVIGATIONAL (AI-suggested, editor-overridable)
7. **Schema builder** — Article, BreadcrumbList, FAQPage, HowTo (only when appropriate)
8. **Slug generator** — `src/lib/seo/slug.ts` — Stable after publication
9. **SEO API** — `POST /api/ai/seo`

#### Files to create
```
src/lib/seo/
  analyzer.ts     — Content analysis (keywords, headings, links, images, etc.)
  scoring.ts      — SEO scoring with configurable weights
  schema.ts       — JSON-LD schema builders
  metadata.ts     — Open Graph, Twitter card, canonical generation
  slug.ts         — Slug generation + stability rules
  types.ts        — SEO types and interfaces

src/app/api/ai/
  seo/route.ts    — POST: analyze and score article SEO
```

#### Files to modify
- `src/components/editor/article-seo-panel.tsx` — Add score display, checklist, recommendations
- `src/lib/ai/editorial.service.ts` — Add analyzeSEO()

#### Acceptance criteria
- [ ] SEO score 0-100 with 10-component breakdown
- [ ] Each component scored individually
- [ ] Checklist shows pass/fail for 15+ items
- [ ] Recommendations are specific and actionable
- [ ] "Fix with AI" button available for fixable items
- [ ] Search intent detected and displayed
- [ ] Schema generated only when appropriate (no fake FAQ schema)
- [ ] Slug stable after publication
- [ ] Scores stored in SeoAnalysis table

---

### SLICE S12 — QUALITY SCORING ENGINE
**Phase**: 1E — SEO + Quality Engine
**Dependencies**: S11
**Status**: ⬜ Not Started

#### What exists today
- No quality scoring
- No originality assessment
- No depth/authority measurement

#### What this slice delivers
1. **Quality service** — `src/lib/ai/quality.service.ts` — `scoreContent()`
2. **Score components** — Originality, SEO, Readability, Search Intent, Depth, Authority, Factual Completeness, Internal Linking, Monetization Readiness
3. **AI-powered scoring** — LLM evaluates content quality
4. **Overall score** — 0-100 aggregate with weighted breakdown
5. **Recommendations** — Actionable improvements when below threshold
6. **Publishing threshold** — Configurable: auto-publish 90+, review 75-89, block below 75
7. **Score API** — `POST /api/ai/quality`
8. **Quality panel** — Populate the placeholder from S6

#### Files to create
```
src/lib/ai/
  quality.service.ts  — scoreContent() with AI evaluation

src/app/api/ai/
  quality/route.ts  — POST: score article quality
```

#### Files to modify
- `src/components/editor/article-quality-panel.tsx` — Display scores, recommendations, threshold warnings

#### Acceptance criteria
- [ ] Quality score 0-100 with 9-component breakdown
- [ ] AI evaluates originality, depth, authority, factual completeness
- [ ] Recommendations shown when below threshold
- [ ] Publishing threshold configurable in settings
- [ ] Warning shown if score below threshold at publish time
- [ ] Admin can override with recorded reason
- [ ] Scores stored in ContentScore table

---

### SLICE S13 — SEO PANEL (EDITOR INTEGRATION)
**Phase**: 1E — SEO + Quality Engine
**Dependencies**: S11, S4
**Status**: ⬜ Not Started

#### What this slice delivers
1. **Integrated SEO/Quality tab** — Combined view in editor right panel
2. **Score gauge** — Visual score display (circular or bar)
3. **Checklist with toggles** — Each SEO check shows pass/fail/warning
4. **Inline fixes** — Click recommendation to apply fix
5. **Live updates** — Score recalculates when content/metadata changes (debounced)
6. **Export** — Schema preview, meta preview, OG preview

#### Files to modify
- `src/components/editor/article-seo-panel.tsx` — Full implementation with scoring
- `src/components/editor/article-quality-panel.tsx` — Full implementation

#### Acceptance criteria
- [ ] SEO score visually displayed with breakdown
- [ ] Quality score visually displayed with breakdown
- [ ] Checklist items show pass/fail with explanations
- [ ] Score updates when content changes (debounced 3s)
- [ ] Meta preview shows how article will appear in search results
- [ ] Schema preview shows JSON-LD output

---

### SLICE S14 — INTERNAL LINKING ENGINE
**Phase**: 1F — Internal Linking + Taxonomy
**Dependencies**: S2
**Status**: ⬜ Not Started

#### What exists today
- No internal linking system
- No link analysis or recommendations

#### What this slice delivers
1. **Link analyzer** — `src/lib/linking/analyzer.ts` — Analyze article content for link opportunities
2. **Link scorer** — `src/lib/linking/scorer.ts` — Score candidates by category, tags, keywords, semantic similarity
3. **Link recommender** — `src/lib/linking/recommender.ts` — Recommend 3-8 relevant links with anchor text
4. **Link rules** — Avoid excessive links, repeated anchors, unrelated content
5. **Link API** — `POST /api/ai/internal-links`
6. **Link panel** — Populate placeholder from S6 with recommendations
7. **Accept/Reject** — Editor can accept or reject each suggestion
8. **Insert** — Accepted links inserted into content at appropriate positions

#### Files to create
```
src/lib/linking/
  analyzer.ts     — Parse article for link opportunities
  scorer.ts       — Score candidate articles for relevance
  recommender.ts  — Generate ranked recommendations
  types.ts        — Link types and interfaces

src/app/api/ai/
  internal-links/route.ts  — POST: get link recommendations
```

#### Files to modify
- `src/components/editor/article-links-panel.tsx` — Show recommendations, accept/reject, insert

#### Acceptance criteria
- [ ] 3-8 relevant internal links recommended per article
- [ ] Each shows: title, relevance %, suggested anchor text, reason
- [ ] Editor can accept/reject individual suggestions
- [ ] Accepted links tracked in InternalLinkRecommendation table
- [ ] No self-links, no excessive repetition
- [ ] Links consider category, tags, keywords, semantic similarity

---

### SLICE S15 — CATEGORY & TAG SYSTEM WITH AI
**Phase**: 1F — Internal Linking + Taxonomy
**Dependencies**: S2, S7
**Status**: ⬜ Not Started

#### What exists today
- Article has a `category` string field (default "AI")
- No Tag model
- No hierarchical categories
- No AI recommendations for taxonomy

#### What this slice delivers
1. **Category CRUD API** — `GET/POST /api/categories`, nested hierarchy
2. **Tag CRUD API** — `GET/POST /api/tags`
3. **AI taxonomy service** — `src/lib/ai/taxonomy.service.ts` — Recommend category + tags
4. **Taxonomy API** — `POST /api/ai/taxonomy`
5. **Category management UI** — Admin view for managing categories
6. **Tag management** — Inline tag creation in editor
7. **Migrate existing** — Map old `category` string to Category records

#### Files to create
```
src/lib/ai/
  taxonomy.service.ts  — recommendTaxonomy() for AI category/tag suggestions

src/lib/taxonomy/
  category.service.ts  — Category CRUD helpers
  tag.service.ts       — Tag CRUD helpers

src/app/api/
  categories/route.ts  — GET: list, POST: create category
  tags/route.ts        — GET: list, POST: create tag

src/app/api/ai/
  taxonomy/route.ts  — POST: AI recommend category/tags
```

#### Files to modify
- `src/components/views/articles-view.tsx` — Show category/tag columns
- `src/components/editor/article-metadata.tsx` — Category selector, tag input
- `src/components/app/app-sidebar.tsx` — Add Categories nav item (optional)

#### Acceptance criteria
- [ ] Categories support hierarchy (parent/child)
- [ ] Tags support multi-select with inline creation
- [ ] AI recommends category + tags when article is created
- [ ] Editor can approve or change AI suggestions
- [ ] Existing articles migrated to new Category/Tag system

---

### SLICE S16 — AUTHOR SYSTEM
**Phase**: 1G — Authors + Article Lifecycle
**Dependencies**: S2
**Status**: ⬜ Not Started

#### What exists today
- No Author model
- No author attribution on articles
- No author pages

#### What this slice delivers
1. **Author CRUD API** — `GET/POST/PUT /api/authors`
2. **Author profile** — Name, username, bio, avatar, website, social links, role
3. **Author assignment** — Assign author to article in editor
4. **Author archive page** — `/author/[slug]` with profile, bio, articles
5. **Article byline** — Display author on public article pages
6. **Migration** — Create default author per existing site

#### Files to create
```
src/app/api/
  authors/route.ts    — GET: list, POST: create author
  authors/[id]/route.ts — PUT: update, DELETE: archive author

src/app/
  author/[slug]/page.tsx  — Public author archive page
```

#### Files to modify
- `src/components/editor/article-metadata.tsx` — Author selector dropdown
- `src/components/blog/blog-article-view.tsx` — Show author byline
- `src/components/blog/blog-home-view.tsx` — Optional author filter

#### Acceptance criteria
- [ ] Authors can be created with full profile
- [ ] Author assigned to articles
- [ ] Public article page shows "By [Name] — [Role]"
- [ ] Author archive page lists their articles
- [ ] Default author created for each existing site

---

### SLICE S17 — ARTICLE VERSIONING
**Phase**: 1G — Authors + Article Lifecycle
**Dependencies**: S2, S4
**Status**: ⬜ Not Started

#### What exists today
- No version history
- No way to see previous versions
- Edits overwrite content directly

#### What this slice delivers
1. **Version creation** — Every major edit creates an ArticleVersion record
2. **Version listing** — Show version history with timestamp, author, change reason
3. **Version comparison** — View two versions side by side (diff view)
4. **Version restore** — Restore a previous version as current
5. **Published version tracking** — Article tracks which version is currently published
6. **History panel** — Populate placeholder from S6
7. **Version API** — `GET/POST /api/articles/:id/versions`

#### Files to create
```
src/lib/articles/
  versioning.ts  — createVersion(), getVersions(), restoreVersion(), compareVersions()

src/app/api/
  articles/[id]/versions/route.ts  — GET: list versions, POST: create version
  articles/[id]/versions/[vid]/route.ts  — POST: restore version
```

#### Files to modify
- `src/components/editor/article-history-panel.tsx` — Version list, view, compare, restore
- `src/app/api/articles/route.ts` — Create version on major edits

#### Acceptance criteria
- [ ] Every major content edit creates a version
- [ ] Version history shows: number, timestamp, author, change reason
- [ ] Can view any previous version
- [ ] Can compare two versions (diff)
- [ ] Can restore a previous version (creates new version, doesn't delete)
- [ ] Published version ID tracked

---

### SLICE S18 — CONTENT REFRESH ENGINE
**Phase**: 1H — Versioning + Refresh
**Dependencies**: S7, S17, S12
**Status**: ⬜ Not Started

#### What exists today
- No refresh system
- No content staleness detection
- No scheduled re-review

#### What this slice delivers
1. **Refresh detector** — `src/lib/content-refresh/detector.ts` — Identify articles needing refresh
2. **Refresh scheduler** — `src/lib/content-refresh/scheduler.ts` — Schedule periodic checks
3. **Refresh service** — `src/lib/content-refresh/service.ts` — Execute refresh workflow
4. **AI refresh workflow** — Analyze old article → identify outdated info → generate update → new version → SEO check → quality check → editor approval
5. **Refresh triggers** — Time-based (30/60/90/180 days), manual, low score, nextReviewAt
6. **Refresh status** — Each article shows: last updated, next review, freshness status
7. **Refresh API** — `POST /api/articles/:id/refresh`
8. **Dashboard integration** — "Needs Refresh" queue

#### Files to create
```
src/lib/content-refresh/
  detector.ts    — Articles needing refresh (age, score, manual)
  scheduler.ts   — Cron job for periodic refresh checks
  service.ts     — Execute refresh workflow
  types.ts       — Refresh types

src/app/api/
  articles/[id]/refresh/route.ts  — POST: trigger refresh
```

#### Files to modify
- `src/lib/scheduler.ts` — Add refresh check cron job
- `src/lib/ai/refresh.service.ts` — AI analysis of outdated content
- `src/components/editor/article-status.tsx` — Show refresh status
- `src/components/dashboard/refresh-queue.tsx` — Articles needing refresh

#### Acceptance criteria
- [ ] Articles >90 days flagged for review
- [ ] Manual refresh available per article
- [ ] AI identifies outdated info and missing sections
- [ ] Refresh creates new version (never overwrites published)
- [ ] SEO and quality re-analyzed after refresh
- [ ] Editor approval required before republishing
- [ ] Dashboard shows articles needing refresh

---

### SLICE S19 — AI JOB QUEUE & COST TRACKING
**Phase**: 1I — Dashboard + Public Blog
**Dependencies**: S7
**Status**: ⬜ Not Started

#### What exists today
- No job tracking
- No cost tracking
- No visibility into AI usage

#### What this slice delivers
1. **AI job creation** — Every AI operation creates an AiJob record
2. **Job statuses** — QUEUED, RUNNING, COMPLETED, FAILED, CANCELLED
3. **Token tracking** — Input/output tokens where available from SDK
4. **Cost estimation** — Based on model + token counts
5. **Job listing** — View all AI jobs with status, duration, cost
6. **Retry logic** — Failed jobs can be retried (max 3 attempts)
7. **Job types** — RESEARCH, OUTLINE, GENERATE, SEO, QUALITY, INTERNAL_LINKS, TAXONOMY, REFRESH

#### Files to create
```
src/lib/ai/
  job.service.ts  — createJob(), updateJob(), retryJob(), listJobs()

src/app/api/
  ai/jobs/route.ts  — GET: list jobs, POST: create job
  ai/jobs/[id]/route.ts  — POST: retry/cancel job
```

#### Files to modify
- `src/lib/ai/client.ts` — Auto-create/update AiJob on every AI call
- All AI route handlers — Use job service

#### Acceptance criteria
- [ ] Every AI operation creates an AiJob record
- [ ] Job shows status, startedAt, completedAt, error, retryCount
- [ ] Token usage and estimated cost tracked
- [ ] Failed jobs show error reason
- [ ] Jobs can be retried up to 3 times
- [ ] Job list filterable by type, status, article

---

### SLICE S20 — API ROUTE RESTRUCTURE
**Phase**: 1I — Dashboard + Public Blog
**Dependencies**: S1–S19
**Status**: ⬜ Not Started

#### What exists today
- Flat route structure: `/api/articles`, `/api/rewrite`, `/api/publish`, `/api/schedule`
- Mixed concerns in single route files
- No auth on most routes (middleware handles it globally)

#### What this slice delivers
1. **Auth routes** — `/api/auth/login`, `/api/auth/logout`, `/api/auth/session`, `/api/auth/reset`
2. **Article routes** — `/api/articles`, `/api/articles/:id`, `/api/articles/:id/submit-review`, `/api/articles/:id/approve`, `/api/articles/:id/publish`, `/api/articles/:id/schedule`, `/api/articles/:id/refresh`
3. **AI routes** — `/api/ai/research`, `/api/ai/outline`, `/api/ai/generate`, `/api/ai/seo`, `/api/ai/quality`, `/api/ai/internal-links`, `/api/ai/taxonomy`, `/api/ai/refresh`, `/api/ai/jobs`
4. **Taxonomy routes** — `/api/categories`, `/api/tags`
5. **Author routes** — `/api/authors`, `/api/authors/:id`
6. **Version routes** — `/api/articles/:id/versions`
7. **Site isolation** — Every operation verifies `article.siteId === user's accessible site`
8. **Keep existing routes** — `/api/feeds`, `/api/sites`, `/api/settings`, `/api/dashboard`, `/api/public` preserved

#### Files to modify
- All new API routes created in previous slices
- Add RBAC guards to all new routes
- Add site isolation checks

#### Acceptance criteria
- [ ] All new endpoints follow REST conventions
- [ ] Every protected endpoint validates session
- [ ] RBAC enforced per endpoint
- [ ] Site isolation verified on all data operations
- [ ] Existing routes still work (backward compatible)
- [ ] Public routes remain unauthenticated

---

### SLICE S21 — DASHBOARD UPGRADE
**Phase**: 1I — Dashboard + Public Blog
**Dependencies**: S3, S12, S14, S18
**Status**: ⬜ Not Started

#### What exists today
- `src/components/views/dashboard-view.tsx` (229 lines)
- Stats cards: feeds, articles by status, bar chart, activity log, recent articles
- No quality metrics, no attention queue, no AI command center

#### What this slice delivers
1. **New metric cards** — Total Articles, Drafts, Published, Scheduled, Needs Review, Needs Refresh, Avg SEO Score, Avg Quality Score
2. **Attention queue** — Clickable items: articles awaiting review, low SEO, missing links, due for refresh, failed AI jobs
3. **AI Command Centre** — Quick actions: Generate Article, Generate Outline, Improve, Optimize SEO, Score, Find Links, Generate Tags, Refresh
4. **Quality overview** — Score distribution chart
5. **Refresh queue** — Articles needing attention
6. **Content pipeline** — Visual pipeline showing articles in each stage

#### Files to create
```
src/components/dashboard/
  metric-card.tsx         — Reusable metric card
  content-pipeline.tsx    — Visual article pipeline
  attention-queue.tsx     — Items needing attention
  quality-overview.tsx   — Score distribution
  refresh-queue.tsx       — Articles due for refresh
  ai-command-centre.tsx   — AI quick actions
  recent-activity.tsx     — Latest activity feed
```

#### Files to modify
- `src/components/views/dashboard-view.tsx` — Replace with new dashboard using above components

#### Acceptance criteria
- [ ] 8 metric cards displayed
- [ ] Attention queue shows actionable items (clickable)
- [ ] AI Command Centre has all 8 quick actions
- [ ] Quality overview shows score distribution
- [ ] Refresh queue shows articles needing refresh
- [ ] Each attention item links to relevant editor screen

---

### SLICE S22 — PUBLIC BLOG ENHANCEMENTS
**Phase**: 1I — Dashboard + Public Blog
**Dependencies**: S2, S16
**Status**: ⬜ Not Started

#### What exists today
- `src/components/blog/blog-home-view.tsx` — Article grid with search, pagination
- `src/components/blog/blog-article-view.tsx` — Article reader with HTML content
- `src/components/blog/blog-header.tsx` — Sticky nav
- `src/components/blog/blog-footer.tsx` — Footer
- `src/app/api/public/route.ts` — Unauthenticated blog data API

#### What this slice delivers
1. **Author display** — Byline on article pages
2. **Category display** — Category badge + link
3. **Tags display** — Tag list on article pages
4. **Publication/updated dates** — "Published Sep 1, 2026 · Updated Sep 1, 2026"
5. **Reading time** — Calculated from word count
6. **Table of contents** — Auto-generated from H2/H3 headings
7. **Related articles** — 3 related articles at bottom (by category, tags, similarity)
8. **Breadcrumbs** — Home > Category > Article
9. **Social sharing** — Share buttons (Twitter, LinkedIn, Facebook)
10. **SEO metadata** — Full meta tags, OG, Twitter cards, schema markup
11. **Sitemap** — `sitemap.xml` auto-generated
12. **Robots.txt** — Already exists, verify correct
13. **Author archive** — `/author/[slug]` page (from S16)
14. **Category archive** — `/category/[slug]` page

#### Files to create
```
src/app/
  blog/[slug]/page.tsx    — Dedicated article page with SEO
  category/[slug]/page.tsx — Category archive page
  sitemap.ts              — Dynamic sitemap generation

src/components/blog/
  blog-toc.tsx            — Table of contents
  blog-related.tsx        — Related articles
  blog-breadcrumbs.tsx    — Breadcrumb navigation
  blog-share.tsx          — Social sharing buttons
  blog-byline.tsx         — Author byline component
```

#### Files to modify
- `src/app/api/public/route.ts` — Add author, category, related articles, tags to response
- `src/components/blog/blog-article-view.tsx` — Add TOC, related, breadcrumbs, byline, share
- `src/components/blog/blog-home-view.tsx` — Add category filters, featured section

#### Acceptance criteria
- [ ] Article pages show author, category, tags, dates, reading time
- [ ] Table of contents generated from headings
- [ ] 3 related articles shown at bottom
- [ ] Breadcrumbs: Home > Category > Article
- [ ] Social sharing buttons functional
- [ ] SEO meta tags, OG, schema in page head
- [ ] Sitemap.xml accessible
- [ ] Author archive page works
- [ ] Category archive page works

---

### SLICE S23 — BUG FIXES & EXISTING CODE CLEANUP
**Phase**: 1J — Testing + Security Audit
**Dependencies**: None (can run in parallel with other slices)
**Status**: ⬜ Not Started

#### What exists today (known bugs)
1. **AdSense double `</p>`** — `insertAdSenseBlocks()` splits on `</p>` and joins with `</p>`, creating doubles
2. **Rollback status** — Publish failure always rolls back to `rewritten` (should use previousStatus — actually this IS using previousStatus now, verify)
3. **Schema URLs** — All schema points to domain root instead of article-specific URL (hardcoded `morewithai.online`)
4. **Hardcoded category** — `fetchFromFeed` in articles route hardcodes category as 'AI'
5. **No rate limiting** — Batch rewrite processes all articles with only 2s delay
6. **seo-panel.tsx** — AdSense toggle calls updateArticle() without siteId
7. **Unused dependencies** — `@dnd-kit/*`, `next-auth`, `next-intl`, `react-markdown`, `react-resizable-panels`, `react-syntax-highlighter`, `uuid`, `zustand` all unused
8. **Client-side search** — Articles search filters current page only, not server-side
9. **No server-side auto-fetch cron** — Scheduler only handles publishing, not feed fetching
10. **Automation route** — Duplicates fetch/rewrite/publish logic instead of calling services

#### What this slice delivers
1. Fix all 10 bugs listed above
2. Remove unused dependencies from package.json
3. Refactor automation route to use shared services
4. Add server-side search to articles API
5. Add rate limiting to batch operations
6. Clean up any other code quality issues found during development

#### Files to modify
- `src/lib/services/publish.service.ts` — Fix AdSense bug, schema URLs
- `src/app/api/articles/route.ts` — Fix hardcoded category, add server-side search
- `src/app/api/rewrite/route.ts` — Add rate limiting
- `src/app/api/automation/route.ts` — Refactor to use services
- `src/components/seo-panel.tsx` — Fix missing siteId
- `src/lib/scheduler.ts` — Add auto-fetch cron option
- `package.json` — Remove unused deps

#### Acceptance criteria
- [ ] AdSense blocks don't create double `</p>` tags
- [ ] Schema URLs are article-specific
- [ ] Category comes from feed settings, not hardcoded
- [ ] Batch operations have rate limiting
- [ ] Automation route calls shared services
- [ ] Server-side search works
- [ ] Unused dependencies removed

---

### SLICE S24 — FINAL INTEGRATION & SECURITY AUDIT
**Phase**: 1J — Testing + Security Audit
**Dependencies**: All previous slices
**Status**: ⬜ Not Started

#### What this slice delivers
1. **End-to-end workflow test** — Full flow from login → create → research → outline → generate → SEO → quality → links → review → schedule → publish → version → refresh
2. **Security audit** — Verify no secrets in frontend, all routes protected, no auth bypass, CSRF protection, rate limiting working
3. **Error handling audit** — All AI operations fail gracefully, no data loss on failure
4. **Performance check** — Pagination working, no N+1 queries, efficient DB access
5. **Migration verification** — Existing data preserved, new tables populated correctly
6. **Documentation** — API routes documented, environment variables documented
7. **Cleanup** — Remove all dead code, unused imports, console.logs

#### Acceptance criteria
- [ ] Full end-to-end workflow works
- [ ] No security vulnerabilities found
- [ ] All AI failures handled gracefully
- [ ] No data loss on any failure scenario
- [ ] Existing articles still accessible
- [ ] All new features functional

---

## PARALLEL EXECUTION MAP

Some slices can be developed in parallel:

```
WEEK 1:
  S1 (Auth) ──────────────────────────────┐
  S23 (Bug Fixes) ─────────────────────────┤ (independent)
                                           │
WEEK 2:                                   │
  S2 (DB Schema) ─── needs S1 ────────────┤
                                           │
WEEK 3:                                   │
  S3 (Status/Lifecycle) ─ needs S2 ───────┤
  S7 (AI Client) ── needs S2 ─────────────┤  (parallel)
  S16 (Authors) ─── needs S2 ─────────────┤
  S15 (Categories/Tags) ─ needs S2, S7 ───┤
                                           │
WEEK 4:                                   │
  S4 (Editor Layout) ─ needs S2 ──────────┤
  S8 (AI Research) ── needs S7 ───────────┤  (parallel)
  S14 (Internal Links) ─ needs S2 ────────┤
  S19 (AI Jobs) ───── needs S7 ───────────┤
                                           │
WEEK 5:                                   │
  S5 (Editor Content) ─ needs S4 ─────────┤
  S6 (Editor Metadata) ─ needs S4, S3 ───┤  (parallel)
  S9 (AI Outline) ──── needs S7 ──────────┤
  S17 (Versioning) ── needs S2, S4 ───────┤
                                           │
WEEK 6:                                   │
  S10 (AI Generator) ─ needs S7, S9 ──────┤
  S18 (Refresh) ───── needs S7, S17, S12 ─┤ (S12 needed)
                                           │
WEEK 7:                                   │
  S11 (SEO Engine) ── needs S10 ──────────┤
  S12 (Quality) ───── needs S11 ──────────┤
                                           │
WEEK 8:                                   │
  S13 (SEO Panel UI) ─ needs S11, S4 ─────┤
  S21 (Dashboard) ──── needs S3, S12 ─────┤  (parallel)
  S22 (Public Blog) ── needs S2, S16 ─────┤
                                           │
WEEK 9:                                   │
  S20 (API Restructure) ──────────────────┤
  S24 (Final Integration) ────────────────┘
```

---

## RISK REGISTER

| Risk | Impact | Mitigation |
|------|--------|------------|
| Prisma SQLite migration breaks existing data | High | Test migration on copy of db/custom.db first; keep all old fields |
| AI prompt quality varies | Medium | Centralized prompts make tuning easy; Zod validation catches bad responses |
| Rich text editor integration issues | Medium | Start with @mdxeditor/editor (already in deps); fallback to textarea |
| Session management complexity | Medium | Use simple DB-backed sessions; defer Redis until needed |
| Scope creep from Phase 2 features | High | Strict slice boundaries; Phase 2 items explicitly excluded |
| Internal linking algorithm quality | Medium | Start with keyword/category matching; improve with semantic similarity later |
| Performance with SQLite at scale | Low | Add indexes; SQLite sufficient for single-site; can migrate to Postgres later |

---

## ENVIRONMENT VARIABLES NEEDED

```env
# Database
DATABASE_URL="file:./db/custom.db"

# Authentication (REMOVE after S1)
# AUTH_PASSWORD="xxx"  ← DELETE THIS

# Session (NEW after S1)
SESSION_SECRET="random-32-char-string"
SESSION_EXPIRY_HOURS=24

# AI
# z-ai-web-dev-sdk handles its own config

# WordPress (existing, preserved)
# wp_site_url, wp_username, wp_app_password per site via Settings

# AdSense (existing, preserved)
# adsense_client_id, adsense_ad_slot per site via Settings

# Content Quality Thresholds (NEW)
PUBLISH_AUTO_SCORE=90
REVIEW_REQUIRED_MIN=75
```

---

## DEFINITION OF DONE

Phase 1 is complete when:

1. ✅ User logs in with email/password (HTTP-only cookie session)
2. ✅ Creates/opens a site
3. ✅ Adds/imports article (from RSS, URL, topic, or manual)
4. ✅ AI researches content (extracts facts, gaps, angles)
5. ✅ AI generates original outline (editable)
6. ✅ User approves outline
7. ✅ AI generates article (8 modes, configurable tone/length/audience)
8. ✅ SEO engine analyzes article (15+ checks, 0-100 score)
9. ✅ Quality engine scores article (9 components, 0-100 score)
10. ✅ Internal-link engine recommends links (3-8 per article)
11. ✅ AI recommends category/tags
12. ✅ Editor reviews all scores and recommendations
13. ✅ Article approved through workflow
14. ✅ Article scheduled
15. ✅ Article publishes to WordPress (with SEO, quality checks, schema)
16. ✅ Version stored automatically
17. ✅ Refresh date scheduled
18. ✅ Dashboard shows all metrics, attention queue, AI command centre
19. ✅ Public blog shows author, category, tags, TOC, related articles, breadcrumbs
20. ✅ Every AI failure is recoverable (no data loss)
