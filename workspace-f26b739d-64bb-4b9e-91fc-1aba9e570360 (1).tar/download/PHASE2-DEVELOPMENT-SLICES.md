# PHASE 2 — MONETIZATION & GROWTH ENGINE
## Development Slice Plan

**Project**: MoreWithAI Blogging Platform V2
**Stack**: Next.js 16 / React 19 / TypeScript / Prisma 6 / SQLite / Tailwind / shadcn
**Objective**: Turn published content into measurable traffic, audience, conversions and revenue
**Dependency**: Phase 1 complete

---

## SLICE OVERVIEW

| Slice | Sprint | Title | Status | Files Created/Modified |
|-------|--------|-------|--------|----------------------|
| S2P | 1 | Database Schema Expansion (30 new models) | Done | schema.prisma |
| S3P | 1 | Subscriber System | Done | 11 files (types, service, 4 API routes, public subscribe, auth perms) |
| S4P | 1 | Lead Capture & Lead Magnets | Done | 8 files (lead service, magnet service, 6 API routes) |
| S5P | 1 | Email Engine | Done | 11 files (provider, templates, campaign/automation/event services, 6 API routes, auth perms) |
| S6P | 2 | CTA Engine (Targeting, Placements, A/B) | Done | 12 files (types, service, placement, targeting, ab-testing, 7 API routes, auth perms) |
| S7P | 3 | Affiliate Engine | Done | 13 files (types, program/offer/tracking/disclosure/recommendation services, 7 API routes, auth perms) |
| S8P | 4 | Product Engine | Done | 5 files (types, service, 3 API routes, auth perms) |
| S9P | 4 | Revenue Event Engine & Attribution | Done | 3 files (types, service, 3 API routes, auth perms) |
| S10P | 5 | Ad Engine | Done | 3 files (types, service, 4 API routes, auth perms) |
| S11P | 5 | Traffic & Search Analytics | Done | 3 service files + 5 API routes + 4 public tracking routes + middleware update |
| S12P | 6 | AI Content Opportunity & Growth Engine | Done | 6 service files + 14 API routes (opportunities, recommendations, money-score, clusters, analyze) |
| S13P | 6 | Sidebar & Navigation Restructure | Done | app-sidebar.tsx rewritten with 6 nav groups, page.tsx updated for 20+ views |
| S14P | 6 | Revenue Dashboard & Top Money Articles | Done | revenue-view.tsx (metrics, source chart, top articles table, 2 funnels) |
| S15P | 6 | Traffic→Money & Email→Money Funnels | Done | Integrated into revenue-view.tsx + analytics-view.tsx |
| S16P | 6 | AI Growth Command Centre | Done | opportunities-view.tsx (AI analysis, recommendations, money score) |
| S17P | 7 | Automation Rules & Daily Growth Review | Done | automation.service.ts + automations-view.tsx + scheduler update |
| S18P | 7 | Social Promotion & Content Repurposing | Done | social service + 4 API routes |
| S19P | 7 | Topic Clusters & Topical Authority | Done | cluster.service.ts + 5 API routes + clusters-view.tsx |
| S20P | 7 | Content Calendar Intelligence | Done | calendar.service.ts + 3 API routes + calendar-view.tsx |
| S21P | 5 | Tracking API & Event System | Done | 4 public tracking routes (pageview, CTA, affiliate, conversion) |
| S22P | 8 | Privacy, Security & Revenue Integrity | Done | Revenue events immutable, adjustments create new records, auth on all routes |
| S23P | 6 | Article Monetization Panel | Done | article-monetization-panel.tsx + editor integration |

---

## ARCHITECTURE OVERVIEW

### Database (48 models total: 18 Phase 1 + 30 Phase 2)

**Audience**: Subscriber, Lead, LeadMagnet
**Email**: EmailCampaign, EmailEvent, EmailAutomation
**Conversion**: CallToAction, CtaPlacement, CtaExperiment, CtaVariant
**Affiliate**: AffiliateProgram, AffiliateOffer, AffiliateClick
**Product**: Product, ProductPurchase
**Advertising**: AdPlacement, AdEvent
**Revenue**: RevenueEvent, RevenueAdjustment
**Analytics**: TrafficMetric, SearchMetric, ConversionEvent
**Growth**: ContentOpportunity, GrowthRecommendation
**Content**: TopicCluster, ClusterArticle, SocialPost, SocialTemplate
**Automation**: AutomationRule, ContentCalendarEvent

### API Routes (60+ new endpoints)

- `/api/subscribers/*` — Subscriber CRUD, stats, export
- `/api/leads/*` — Lead capture, stats
- `/api/lead-magnets/*` — Lead magnet CRUD, stats
- `/api/email/campaigns/*` — Campaign CRUD, send, schedule
- `/api/email/automations/*` — Automation CRUD
- `/api/email/stats` — Event statistics
- `/api/ctas/*` — CTA CRUD, stats, targeting
- `/api/ctas/placements/*` — Placement management
- `/api/ctas/experiments/*` — A/B testing
- `/api/affiliates/programs/*` — Program CRUD
- `/api/affiliates/offers/*` — Offer CRUD, stats
- `/api/affiliates/tracking` — Click tracking (public)
- `/api/affiliates/recommendations` — AI recommendations
- `/api/affiliates/disclosure` — Affiliate disclosure (public)
- `/api/products/*` — Product CRUD, stats
- `/api/products/purchases` — Purchase records
- `/api/ads/placements/*` — Ad placement CRUD
- `/api/ads/stats` — Ad performance
- `/api/ads/events` — Ad event tracking (public)
- `/api/revenue` — Revenue dashboard, sources, articles
- `/api/revenue/adjustments` — Revenue corrections
- `/api/analytics/*` — Traffic, search, conversion, funnel
- `/api/growth/opportunities/*` — AI opportunities
- `/api/growth/recommendations/*` — AI recommendations
- `/api/growth/money-score` — Money opportunity scoring
- `/api/growth/analyze` — Comprehensive AI analysis
- `/api/growth/clusters/*` — Topic clusters + articles + gaps + metrics
- `/api/social/posts/*` — Social post management
- `/api/social/templates/*` — Social templates
- `/api/calendar/*` — Content calendar + AI suggestions
- `/api/automation/rules/*` — Automation rules + evaluate
- `/api/events/*` — Public tracking (pageview, CTA, affiliate, conversion)

### Service Layer (20+ service files)

`src/lib/subscriber/`, `src/lib/lead/`, `src/lib/lead-magnet/`, `src/lib/email/` (5 files), `src/lib/cta/` (4 files), `src/lib/affiliate/` (5 files), `src/lib/product/`, `src/lib/revenue/`, `src/lib/ad/`, `src/lib/analytics/` (3 files), `src/lib/growth/` (5 files), `src/lib/social/`, `src/lib/calendar/`

### UI Views (13 new views)

- **Revenue Dashboard**: Revenue metrics, source chart, top money articles, traffic/email funnels
- **Analytics**: Traffic trends, search performance, conversion breakdown, top traffic articles
- **Subscribers**: Subscriber management, search, stats, create/unsubscribe
- **Email Campaigns**: Campaign + automation management with send/schedule
- **CTAs**: CTA management with A/B experiment creation
- **Affiliates**: Program + offer management with stats
- **Products**: Product + purchase management with revenue tracking
- **Lead Magnets**: Lead magnet CRUD with delivery tracking
- **Ads**: Ad placement management with performance stats
- **Opportunities**: AI-powered content opportunities + growth recommendations
- **Topic Clusters**: Cluster management with authority scoring + gap analysis
- **Content Calendar**: Month view calendar with AI suggestions
- **Automations**: Rule-based automation with JSON conditions/actions
- **Article Monetization Panel**: In-editor revenue/score/recommendations panel

### Sidebar Navigation (6 groups)

- **Overview**: Dashboard
- **Content**: Articles, AI Writer, Review Queue, Content Opportunities
- **Growth**: Analytics, SEO, Topic Clusters, Content Calendar
- **Monetization**: Revenue, Affiliates, Products, CTAs, Lead Magnets, Ads
- **Audience**: Subscribers, Email Campaigns, Automations
- **System**: RSS Feeds, Settings

### Scheduled Jobs (3 cron jobs)

1. Every 5 min: Auto-publish scheduled articles
2. Daily 3 AM: Content freshness check + refresh
3. Daily 4 AM: Daily growth review (analyze opportunities + generate recommendations + evaluate rules)

### Permissions (14 new permissions)

- `subscriber.read`, `subscriber.write`
- `email.read`, `email.write`
- `cta.read`, `cta.write`
- `affiliate.read`, `affiliate.write`
- `product.read`, `product.write`
- `ad.read`, `ad.write`
- `revenue.read`, `revenue.write`
- `analytics.read`, `analytics.write`
- `growth.read`, `growth.write`

---

## DEFINITION OF DONE

- [x] Which articles bring visitors? → Traffic Analytics
- [x] Which articles generate subscribers? → Subscriber tracking by source
- [x] Which CTAs convert? → CTA analytics + A/B testing
- [x] Which articles generate affiliate clicks and commissions? → Affiliate tracking + attribution
- [x] Which articles sell products? → Product purchase tracking + revenue events
- [x] Which pages generate ad revenue? → Ad event tracking
- [x] How much money does each article generate? → Revenue dashboard + RPM + article attribution
- [x] What should we improve next? → AI Growth Engine + recommendations
- [x] What is the highest-value growth opportunity? → Money Opportunity Score + Growth Command Centre
