// Dynamic import approach for ZAI SDK
import { db } from '@/lib/db';

export interface AiCallOptions {
  siteId: string;
  articleId?: string;
  jobType: string;
  systemPrompt: string;
  userPrompt: string;
}

export interface AiCallResult {
  content: string;
  usage?: { inputTokens?: number; outputTokens?: number };
}

export async function callAI(options: AiCallOptions): Promise<AiCallResult> {
  const { siteId, articleId, jobType, systemPrompt, userPrompt } = options;
  let job: { id: string } | null = null;
  try {
    job = await db.aiJob.create({ data: { siteId, articleId: articleId || null, type: jobType, status: 'RUNNING', startedAt: new Date() } });
  } catch {}

  let lastError: Error | null = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const ZAI = require('z-ai-web-dev-sdk');
      const sdk = new (ZAI.default || ZAI.ZAI || ZAI)();
      const response = await sdk.chat.completions.create({
        model: 'default',
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }],
      });
      const content = response.choices?.[0]?.message?.content || '';
      const rawUsage = (response as any).usage;
      const inputTokens = rawUsage?.input_tokens;
      const outputTokens = rawUsage?.output_tokens;
      if (job) {
        await db.aiJob.update({ where: { id: job.id }, data: { status: 'COMPLETED', completedAt: new Date(), inputTokens: inputTokens || null, outputTokens: outputTokens || null, estimatedCost: estimateCost(inputTokens, outputTokens) } }).catch(() => {});
      }
      return { content, usage: { inputTokens, outputTokens } };
    } catch (error) {
      lastError = error as Error;
      if (attempt === 0) await new Promise((r) => setTimeout(r, 1000));
    }
  }
  const errorMsg = lastError?.message || 'AI call failed';
  if (job) { await db.aiJob.update({ where: { id: job.id }, data: { status: 'FAILED', error: errorMsg, completedAt: new Date(), retryCount: 2 } }).catch(() => {}); }
  throw new Error(errorMsg);
}

function estimateCost(i?: number, o?: number): number | null {
  if (!i && !o) return null;
  return Math.round(((i || 0) / 1e6 * 3 + (o || 0) / 1e6 * 15) * 10000) / 10000;
}

export function cleanAIResponse(text: string): string {
  return text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
}
