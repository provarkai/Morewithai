import { db } from "@/lib/db";
const sdk = require("z-ai-web-dev-sdk");
const zai = new (sdk.default || sdk.ZAI || sdk)();





function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function rewriteArticleWithSEO(
  articleId: string,
  title: string,
  content: string,
): Promise<boolean> {
  try {
    await db.article.update({ where: { id: articleId }, data: { status: 'rewriting' } });

    const prompt = `You are an expert blog writer and SEO specialist for "MoreWithAI". Rewrite the following article and generate SEO metadata.

RULES FOR CONTENT:
- Create a compelling, click-worthy title (60 chars max for SEO)
- Write in an informative yet conversational tone
- Add your own insights and commentary
- Structure with clear paragraphs and subheadings using <h2> and <h3> HTML tags
- Make it at least 500 words if the original is substantial
- Do NOT copy phrases verbatim - rephrase everything
- Add a hook intro that engages the reader
- End with a forward-looking conclusion
- Include a \"Key Takeaways\" section at the end as a <ul> list

Original Title: ${title}

Original Content:
${content}

Respond with ONLY valid JSON in this exact format (no markdown wrapping):
{
  \"title\": \"your rewritten title (max 60 chars)\",
  \"content\": \"your full rewritten article HTML content\",
  \"seoTitle\": \"SEO meta title (50-60 chars, include primary keyword)\",
  \"seoDescription\": \"SEO meta description (150-160 chars, compelling summary with keywords)\",
  \"seoKeywords\": \"keyword1, keyword2, keyword3, keyword4, keyword5 (5-8 relevant keywords)\",
  \"schemaMarkup\": \"JSON-LD schema markup as a string for Article type\"
}`;

    const response = await sdk.chat.completions.create({
      model: 'default',
      messages: [
        {
          role: 'system',
          content: 'You are a professional blog content rewriter and SEO expert. Always respond with valid JSON only, no markdown code blocks.',
        },
        { role: 'user', content: prompt },
      ],
    });

    let rewritten = response.choices?.[0]?.message?.content || '';
    rewritten = rewritten.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const parsed = JSON.parse(rewritten);

    if (!parsed.title || !parsed.content) {
      throw new Error('LLM returned missing title or content');
    }

    const slug = parsed.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 80);
    const articleUrl = `https://morewithai.online/blog/${slug}`;

    let schemaMarkup = parsed.schemaMarkup;
    if (!schemaMarkup && parsed.seoDescription) {
      const schema = {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: parsed.seoTitle || parsed.title,
        description: parsed.seoDescription,
        author: { '@type': 'Organization', name: 'MoreWithAI' },
        publisher: { '@type': 'Organization', name: 'MoreWithAI', url: 'https://morewithai.online' },
        url: articleUrl,
        mainEntityOfPage: { '@type': 'WebPage', '@id': articleUrl },
      };
      schemaMarkup = JSON.stringify(schema);
    }

    await db.article.update({
      where: { id: articleId },
      data: {
        title: parsed.title,
        rewrittenTitle: parsed.title,
        rewrittenContent: parsed.content,
        seoTitle: parsed.seoTitle || null,
        seoDescription: parsed.seoDescription || null,
        seoKeywords: parsed.seoKeywords || null,
        seoSchema: schemaMarkup || null,
        status: 'rewritten',
        rewrittenAt: new Date(),
      },
    });

    return true;
  } catch (error) {
    console.error(`Error rewriting article ${articleId}:`, error);
    await db.article.update({
      where: { id: articleId },
      data: { status: 'fetched', errorMessage: String(error) },
    });
    return false;
  }
}

export async function batchRewriteWithSEO(
  articles: { id: string; originalTitle: string; originalContent: string }[],
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  for (let i = 0; i < articles.length; i++) {
    const article = articles[i];
    const result = await rewriteArticleWithSEO(article.id, article.originalTitle, article.originalContent);
    if (result) success++;
    else failed++;
    if (i < articles.length - 1) await delay(2000);
  }

  return { success, failed };
}
