import cron from 'node-cron';
import { db } from '@/lib/db';
import { publishArticle } from '@/lib/services/publish.service';
import { runScheduledRefreshCheck } from '@/lib/content-refresh/service';
import { runDailyGrowthReview } from '@/lib/growth/automation.service';

let scheduled = false;

export function startScheduler() {
  if (scheduled) return;
  scheduled = true;
  console.log('[Scheduler] Starting background scheduler...');

  // Every 5 minutes: publish due scheduled articles across all sites
  cron.schedule('*/5 * * * *', async () => {
    try {
      const dueArticles = await db.article.findMany({
        where: {
          status: 'scheduled',
          scheduledAt: { lte: new Date() },
        },
      });

      if (dueArticles.length === 0) return;

      let success = 0;
      let failed = 0;

      for (const article of dueArticles) {
        const result = await publishArticle(article.id);
        if (result) success++;
        else failed++;
      }

      // Group by siteId for logging
      const siteGroups = new Map<string, { success: number; failed: number }>();
      for (const article of dueArticles) {
        const existing = siteGroups.get(article.siteId) || { success: 0, failed: 0 };
        siteGroups.set(article.siteId, existing);
      }

      // Log per site
      for (const [siteId] of siteGroups) {
        await db.automationLog.create({
          data: {
            action: 'scheduled-publish',
            status: failed === 0 ? 'success' : 'partial',
            message: `Auto-published ${success} scheduled articles${failed > 0 ? `, ${failed} failed` : ''}`,
            siteId,
          },
        });
      }

      console.log(`[Scheduler] Done: ${success} published, ${failed} failed`);
    } catch (error) {
      // Logged via automation log, not console
    }
  });

  // Daily at 3 AM: check articles due for content refresh
  cron.schedule('0 3 * * *', async () => {
    try {
      const results = await runScheduledRefreshCheck();
      console.log(`[Scheduler] Refresh check: ${results.succeeded} refreshed, ${results.skipped} skipped, ${results.failed} failed`);
    } catch {
      // Non-blocking — will retry next day
    }
  });

  // Daily at 4 AM: run daily growth review across all active sites
  cron.schedule('0 4 * * *', async () => {
    try {
      const results = await runDailyGrowthReview();
      console.log(`[Scheduler] Growth review: ${results.length} sites processed`);
    } catch {
      // Non-blocking — will retry next day
    }
  });

  console.log('[Scheduler] Background scheduler active (publish: 5min, refresh: daily 3AM, growth: daily 4AM)');
}