import { db } from '@/lib/db';
import type { EmailResult } from './types';

export interface EmailProvider {
  send(
    to: string,
    subject: string,
    html: string,
    options?: {
      from?: string;
      replyTo?: string;
      previewText?: string;
    },
  ): Promise<EmailResult>;
}

/**
 * LogProvider — logs emails to console and returns success.
 * Used for development and testing.
 */
class LogProvider implements EmailProvider {
  async send(
    to: string,
    subject: string,
    html: string,
    options?: { from?: string; replyTo?: string; previewText?: string },
  ): Promise<EmailResult> {
    console.log('─── 📧 EMAIL (LogProvider) ───');
    console.log(`  To:      ${to}`);
    console.log(`  From:    ${options?.from ?? '(default)'}`);
    console.log(`  ReplyTo: ${options?.replyTo ?? '(none)'}`);
    console.log(`  Subject: ${subject}`);
    console.log(`  Preview: ${options?.previewText ?? '(none)'}`);
    console.log(`  HTML:    ${html.length > 200 ? html.slice(0, 200) + '...' : html}`);
    console.log('─────────────────────────────');

    return {
      success: true,
      messageId: `log_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
    };
  }
}

const logProvider = new LogProvider();

/**
 * Resolves the appropriate email provider for a site based on its settings.
 * Falls back to LogProvider when no provider is configured.
 */
export async function getEmailProvider(siteId: string): Promise<EmailProvider> {
  try {
    const setting = await db.setting.findUnique({
      where: { key_siteId: { key: 'email_provider', siteId } },
    });

    if (!setting) {
      return logProvider;
    }

    const providerType = setting.value;

    switch (providerType) {
      case 'smtp': {
        // Placeholder: SMTP provider would be loaded here
        // For now fall through to log
        console.warn(`[email] SMTP provider not yet implemented, using LogProvider for site ${siteId}`);
        return logProvider;
      }
      case 'sendgrid': {
        // Placeholder: SendGrid provider would be loaded here
        console.warn(`[email] SendGrid provider not yet implemented, using LogProvider for site ${siteId}`);
        return logProvider;
      }
      case 'mailgun': {
        // Placeholder: Mailgun provider would be loaded here
        console.warn(`[email] Mailgun provider not yet implemented, using LogProvider for site ${siteId}`);
        return logProvider;
      }
      case 'log':
      default:
        return logProvider;
    }
  } catch {
    return logProvider;
  }
}
