import { NextRequest, NextResponse } from 'next/server';
import { requirePermission } from '@/lib/auth/guards';
import { executeRefresh } from '@/lib/content-refresh/service';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requirePermission('article.edit');
    const { id } = await params;
    const { siteId, reason } = await req.json();

    if (!siteId) {
      return NextResponse.json({ error: 'siteId is required' }, { status: 400 });
    }

    const result = await executeRefresh(id, siteId, reason || 'MANUAL');
    return NextResponse.json(result);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Content refresh failed';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
