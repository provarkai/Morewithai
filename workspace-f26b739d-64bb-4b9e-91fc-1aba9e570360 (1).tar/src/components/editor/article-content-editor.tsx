"use client";

import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { Image, Type, AlignLeft, Hash, Link, ListOrdered, Bold, Italic, Heading2, Minus, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

interface ArticleContentEditorProps {
  title: string;
  content: string;
  onTitleChange: (title: string) => void;
  onContentChange: (content: string) => void;
  readOnly?: boolean;
}

interface ContentStats {
  words: number;
  characters: number;
  paragraphs: number;
  headings: number;
  images: number;
  internalLinks: number;
  externalLinks: number;
  readingTime: number;
}

function computeStats(html: string): ContentStats {
  if (!html) return { words: 0, characters: 0, paragraphs: 0, headings: 0, images: 0, internalLinks: 0, externalLinks: 0, readingTime: 0 };
  const text = html.replace(/<[^>]*>/g, '').replace(/&[a-z]+;/gi, ' ').replace(/\s+/g, ' ').trim();
  const words = text ? text.split(/\s+/).length : 0;
  const paragraphs = (html.match(/<p[\s>]/gi) || []).length || (text.length > 0 ? 1 : 0);
  const headings = (html.match(/<h[2-6][\s>]/gi) || []).length;
  const images = (html.match(/<img[\s>]/gi) || []).length;
  const links = (html.match(/<a[^>]+href=["']([^"']+)["']/gi) || []);
  let internalLinks = 0;
  let externalLinks = 0;
  links.forEach((l) => {
    const match = l.match(/href=["']([^"']+)["']/);
    if (match && !match[1].startsWith('#') && !match[1].startsWith('mailto:')) {
      externalLinks++;
    }
  });
  const readingTime = Math.max(1, Math.ceil(words / 200));
  return { words, characters: text.length, paragraphs, headings, images, internalLinks, externalLinks, readingTime };
}

export function ArticleContentEditor({
  title,
  content,
  onTitleChange,
  onContentChange,
  readOnly = false,
}: ArticleContentEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showStats, setShowStats] = useState(false);
  const [insertMode, setInsertMode] = useState<string | null>(null);

  const stats = useMemo(() => computeStats(content), [content]);

  // Insert HTML tag at cursor position
  const insertAtCursor = useCallback((tag: string, isBlock = false) => {
    const ta = textareaRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const selected = content.substring(start, end);
    let insertion = '';
    if (isBlock) {
      const before = content.substring(0, start);
      const needsNewline = before.length > 0 && !before.endsWith('\n');
      insertion = (needsNewline ? '\n' : '') + `<${tag}>${selected || 'Text here'}</${tag}>\n`;
    } else {
      insertion = `<${tag}>${selected || 'text'}</${tag}>`;
    }
    const newContent = content.substring(0, start) + insertion + content.substring(end);
    onContentChange(newContent);
    // Restore cursor
    requestAnimationFrame(() => {
      ta.focus();
      const newPos = start + insertion.length - (selected ? 0 : `<${tag}>`.length + `</${tag}>`.length);
      ta.setSelectionRange(newPos, newPos + (selected ? selected.length : 0));
    });
    setInsertMode(null);
  }, [content, onContentChange]);

  const toolbarActions = [
    { key: 'h2', label: 'Heading 2', icon: Heading2, tag: 'h2', block: true },
    { key: 'h3', label: 'Heading 3', icon: Heading2, tag: 'h3', block: true },
    { key: 'p', label: 'Paragraph', icon: AlignLeft, tag: 'p', block: true },
    { key: 'bold', label: 'Bold', icon: Bold, tag: 'strong' },
    { key: 'italic', label: 'Italic', icon: Italic, tag: 'em' },
    { key: 'ul', label: 'Bullet List', icon: List, tag: 'ul', block: true },
    { key: 'ol', label: 'Numbered List', icon: ListOrdered, tag: 'ol', block: true },
    { key: 'hr', label: 'Horizontal Rule', icon: Minus, tag: 'hr', block: true },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Title Input */}
      <div className="px-4 pt-4">
        <input
          type="text"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          placeholder="Article title..."
          readOnly={readOnly}
          className="w-full text-2xl font-bold bg-transparent border-none outline-none placeholder:text-muted-foreground/50 focus:outline-none"
        />
      </div>

      <Separator className="mx-4 mt-2" />

      {/* Toolbar */}
      {!readOnly && (
        <div className="flex items-center gap-0.5 px-4 py-1.5 border-b overflow-x-auto">
          {toolbarActions.map((action) => {
            const Icon = action.icon;
            return (
              <Button
                key={action.key}
                variant="ghost"
                size="icon"
                className="size-7 shrink-0"
                onClick={() => insertAtCursor(action.tag, action.block)}
                title={action.label}
              >
                <Icon className="size-3.5" />
              </Button>
            );
          })}
          <div className="flex-1" />
          <Button
            variant={showStats ? "secondary" : "ghost"}
            size="sm"
            className="h-7 gap-1 text-xs shrink-0"
            onClick={() => setShowStats(!showStats)}
          >
            <Type className="size-3" />
            {stats.words}w · {stats.readingTime}min
          </Button>
        </div>
      )}

      {/* Stats bar */}
      {showStats && (
        <div className="flex items-center gap-3 px-4 py-1.5 bg-muted/50 text-[11px] text-muted-foreground border-b overflow-x-auto">
          <span><strong>{stats.words}</strong> words</span>
          <span><strong>{stats.characters}</strong> chars</span>
          <span><strong>{stats.paragraphs}</strong> paragraphs</span>
          <span><strong>{stats.headings}</strong> headings</span>
          {stats.images > 0 && <span><strong>{stats.images}</strong> images</span>}
          <span><strong>{stats.externalLinks}</strong> links</span>
          <span><strong>{stats.readingTime}</strong> min read</span>
        </div>
      )}

      {/* Content Area */}
      <div className="flex-1 min-h-0">
        {readOnly ? (
          <div className="h-full overflow-y-auto p-4">
            <div
              className="prose prose-sm dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: content || '<p className="text-muted-foreground">No content</p>' }}
            />
          </div>
        ) : (
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => onContentChange(e.target.value)}
            placeholder="Write or paste your article content here...\n\nUse the toolbar above to insert HTML tags, or write HTML directly."
            className="w-full h-full resize-none p-4 bg-transparent font-mono text-sm leading-relaxed border-none outline-none placeholder:text-muted-foreground/50"
            spellCheck={false}
          />
        )}
      </div>
    </div>
  );
}

export { computeStats };
export type { ContentStats };
