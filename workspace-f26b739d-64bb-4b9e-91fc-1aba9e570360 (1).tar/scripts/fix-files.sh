#!/bin/bash
# Fix files that were written as single lines

# Fix quality.service.ts
cat > src/lib/ai/quality.service.ts << 'EOF'
import { callAI, cleanAIResponse } from './client';
import { parseAIResponse, QualityScoreResultSchema } from './schemas';
import { getQualityPrompt } from './prompts';
import { db } from '@/lib/db';

export async function scoreContent(articleId: string, siteId: string): Promise<Record<string, unknown>> {
  const article = await db.article.findUnique({ where: { id: articleId } });
  if (!article) throw new Error('Article not found');

  const prompt = getQualityPrompt({
    title: article.rewrittenTitle || article.title,
    content: article.rewrittenContent || article.originalContent,
    primaryKeyword: article.primaryKeyword || undefined,
  });

  const result = await callAI({
    siteId,
    articleId,
    jobType: 'QUALITY',
    systemPrompt: 'You are a content quality evaluator. Always respond with valid JSON only, no markdown.',
    userPrompt: prompt,
  });

  const score = parseAIResponse(cleanAIResponse(result.content), QualityScoreResultSchema);

  await db.contentScore.upsert({
    where: { articleId },
    create: {
      articleId,
      overallScore: score.overallScore,
      originalityScore: score.originalityScore,
      readabilityScore: score.readabilityScore,
      searchIntentScore: score.searchIntentScore,
      depthScore: score.depthScore,
      authorityScore: score.authorityScore,
      factualScore: score.factualScore,
      internalLinkScore: score.internalLinkScore,
      monetizationReadinessScore: score.monetizationReadinessScore,
      recommendations: score.recommendations?.join('\n') || null,
    },
    update: {
      overallScore: score.overallScore,
      originalityScore: score.originalityScore,
      readabilityScore: score.readabilityScore,
      searchIntentScore: score.searchIntentScore,
      depthScore: score.depthScore,
      authorityScore: score.authorityScore,
      factualScore: score.factualScore,
      internalLinkScore: score.internalLinkScore,
      monetizationReadinessScore: score.monetizationReadinessScore,
      recommendations: score.recommendations?.join('\n') || null,
    },
  });

  await db.article.update({
    where: { id: articleId },
    data: {
      qualityScore: score.overallScore,
      lastReviewedAt: new Date(),
    },
  });

  return score;
}
EOF
echo 'quality.service.ts fixed'
