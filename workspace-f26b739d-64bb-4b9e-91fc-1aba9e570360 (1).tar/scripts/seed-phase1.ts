import { PrismaClient } from '@prisma/client';
import { hashPassword } from '../src/lib/auth/password';

const db = new PrismaClient();

async function seed() {
  console.log('🌱 Phase 1 Seeding...');

  // 1. Create default admin user
  const existingAdmin = await db.user.findFirst({ where: { role: 'ADMIN' } });
  if (!existingAdmin) {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@morewithai.online';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123'; // Change in production!
    const hash = await hashPassword(adminPassword);

    const admin = await db.user.create({
      data: {
        email: adminEmail.toLowerCase(),
        name: 'Admin',
        passwordHash: hash,
        role: 'ADMIN',
        isActive: true,
      },
    });
    console.log(`✅ Admin user created: ${admin.email}`);

    // Grant admin access to all existing sites
    const sites = await db.site.findMany();
    for (const site of sites) {
      await db.userSite.create({
        data: { userId: admin.id, siteId: site.id, role: 'ADMIN' },
      }).catch(() => {}); // ignore duplicates
    }
    console.log(`✅ Admin granted access to ${sites.length} site(s)`);
  } else {
    console.log(`ℹ️  Admin user already exists: ${existingAdmin.email}`);
  }

  // 2. Create default author for each site that has no authors
  const sites = await db.site.findMany({
    include: { authors: true },
  });

  for (const site of sites) {
    if (site.authors.length === 0) {
      const author = await db.author.create({
        data: {
          siteId: site.id,
          name: site.name + ' Editor',
          slug: site.slug + '-editor',
          bio: `The editorial team behind ${site.name}.`,
          isActive: true,
        },
      });
      console.log(`✅ Default author created for site "${site.name}": ${author.name}`);
    }
  }

  // 3. Create default category for each site
  for (const site of sites) {
    const existingCats = await db.category.count({ where: { siteId: site.id } });
    if (existingCats === 0) {
      await db.category.create({
        data: {
          siteId: site.id,
          name: 'AI',
          slug: 'ai',
          description: 'Artificial Intelligence news, guides, and insights',
        },
      });
      console.log(`✅ Default category created for site "${site.name}"`);
    }
  }

  // 4. Migrate existing articles — generate slugs and assign default author/category
  const articlesWithoutSlug = await db.article.findMany({
    where: { slug: null },
    include: { site: true, author: true, category: true },
  });

  let migrated = 0;
  for (const article of articlesWithoutSlug) {
    const title = article.rewrittenTitle || article.title;
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 80);

    // Find default author for this site
    const author = await db.author.findFirst({
      where: { siteId: article.siteId, isActive: true },
    });

    // Find default category
    const category = await db.category.findFirst({
      where: { siteId: article.siteId },
    });

    // Calculate word count
    const content = article.rewrittenContent || article.originalContent;
    const words = content.replace(/<[^>]*>/g, '').split(/\s+/).filter(Boolean).length;

    await db.article.update({
      where: { id: article.id },
      data: {
        slug,
        authorId: author?.id,
        categoryId: category?.id,
        wordCount: words,
        readingTime: Math.max(1, Math.ceil(words / 200)),
      },
    });
    migrated++;
  }
  console.log(`✅ Migrated ${migrated} article(s) with slugs, authors, categories`);

  // 5. Create ArticleSource records for existing articles with sourceUrl
  const articlesWithSources = await db.article.findMany({
    where: {
      sourceUrl: { not: '' },
      sources: { none: {} },
    },
  });

  for (const article of articlesWithSources) {
    await db.articleSource.create({
      data: {
        articleId: article.id,
        url: article.sourceUrl,
        title: article.originalTitle,
        sourceType: article.sourceFeedId ? 'RSS' : 'URL',
        excerpt: article.originalContent.slice(0, 300),
      },
    });
  }
  console.log(`✅ Created ${articlesWithSources.length} article source record(s)`);

  console.log('\n✨ Phase 1 seeding complete!');
}

seed()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
