import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Create default site first
  let site = await prisma.site.findFirst({ where: { slug: 'morewithai' } });
  if (!site) {
    site = await prisma.site.create({
      data: {
        name: 'MoreWithAI',
        slug: 'morewithai',
        description: 'AI news and insights, curated and enhanced by AI',
      },
    });
    console.log(`Created site: ${site.name}`);
  } else {
    console.log(`Site already exists: ${site.name}`);
  }

  const feeds = [
    { name: 'OpenAI Blog', url: 'https://openai.com/blog/rss.xml', category: 'AI' },
    { name: 'Google AI Blog', url: 'https://blog.google/technology/ai/rss/', category: 'AI' },
    { name: 'MIT Technology Review AI', url: 'https://www.technologyreview.com/feed/', category: 'AI' },
    { name: 'The Verge - AI', url: 'https://www.theverge.com/rss/ai-artificial-intelligence/index.xml', category: 'AI' },
    { name: 'TechCrunch AI', url: 'https://techcrunch.com/category/artificial-intelligence/feed/', category: 'AI' },
    { name: 'AI News', url: 'https://artificialintelligence-news.com/feed/', category: 'AI' },
  ];

  for (const feed of feeds) {
    const existing = await prisma.rssFeed.findFirst({
      where: { url: feed.url, siteId: site.id },
    });
    if (!existing) {
      await prisma.rssFeed.create({ data: { ...feed, siteId: site.id } });
      console.log(`  Added feed: ${feed.name}`);
    } else {
      console.log(`  Feed exists: ${feed.name}`);
    }
  }
  console.log('Done!');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
