-- AlterTable
ALTER TABLE "Product" ADD COLUMN "content" TEXT;

-- AlterTable
ALTER TABLE "Article" ADD COLUMN "premiumTierId" TEXT;

-- CreateTable
CREATE TABLE "ReaderSubscription" (
    "id" TEXT NOT NULL,
    "subscriberId" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "planId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "provider" TEXT NOT NULL DEFAULT 'STRIPE',
    "externalId" TEXT,
    "currentPeriodStart" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "currentPeriodEnd" TIMESTAMP(3),
    "canceledAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ReaderSubscription_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ReaderSubscription_subscriberId_status_idx" ON "ReaderSubscription"("subscriberId", "status");

-- CreateIndex
CREATE INDEX "ReaderSubscription_siteId_idx" ON "ReaderSubscription"("siteId");

-- CreateIndex
CREATE INDEX "ReaderSubscription_provider_externalId_idx" ON "ReaderSubscription"("provider", "externalId");

-- AddForeignKey
ALTER TABLE "ReaderSubscription" ADD CONSTRAINT "ReaderSubscription_subscriberId_fkey" FOREIGN KEY ("subscriberId") REFERENCES "Subscriber"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReaderSubscription" ADD CONSTRAINT "ReaderSubscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES "Plan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
