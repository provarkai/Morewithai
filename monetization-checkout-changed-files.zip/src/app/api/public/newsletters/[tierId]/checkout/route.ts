import { NextRequest, NextResponse } from 'next/server';
import { createNewsletterCheckoutSession } from '@/lib/monetization/paid-newsletters.service';

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: NextRequest, { params }: { params: { tierId: string } }) {
  try {
    const { tierId } = params;
    const body = await req.json();
    const { siteId, email, successUrl, cancelUrl } = body;

    if (!siteId) return NextResponse.json({ error: 'siteId required' }, { status: 400 });
    if (!email || typeof email !== 'string' || !emailRegex.test(email)) {
      return NextResponse.json({ error: 'Valid email required' }, { status: 400 });
    }
    if (!successUrl || !cancelUrl) {
      return NextResponse.json({ error: 'successUrl and cancelUrl required' }, { status: 400 });
    }

    const session = await createNewsletterCheckoutSession(siteId, tierId, email, successUrl, cancelUrl);
    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error('Newsletter checkout error:', error);
    return NextResponse.json({ error: error.message || 'Checkout failed' }, { status: 400 });
  }
}
