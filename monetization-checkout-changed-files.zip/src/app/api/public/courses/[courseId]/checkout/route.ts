import { NextRequest, NextResponse } from 'next/server';
import { createCourseCheckoutSession } from '@/lib/monetization/course-builder.service';

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: NextRequest, { params }: { params: { courseId: string } }) {
  try {
    const { courseId } = params;
    const body = await req.json();
    const { email, successUrl, cancelUrl } = body;

    if (!email || typeof email !== 'string' || !emailRegex.test(email)) {
      return NextResponse.json({ error: 'Valid email required' }, { status: 400 });
    }
    if (!successUrl || !cancelUrl) {
      return NextResponse.json({ error: 'successUrl and cancelUrl required' }, { status: 400 });
    }

    const session = await createCourseCheckoutSession(courseId, email, successUrl, cancelUrl);
    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error('Course checkout error:', error);
    return NextResponse.json({ error: error.message || 'Checkout failed' }, { status: 400 });
  }
}
